import {bootstrap}    from 'angular2/platform/browser'
import {AppComponent} from "./components/app/app.component";
bootstrap(AppComponent);