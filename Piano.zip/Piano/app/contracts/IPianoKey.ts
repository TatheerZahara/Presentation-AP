export interface IPianoKey {
    whiteKeyId: number;
    blackKeyId: number;
}