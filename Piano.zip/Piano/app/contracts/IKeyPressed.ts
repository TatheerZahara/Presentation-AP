export interface IKeyPressed {
    key: number;
    keyType: string;
}