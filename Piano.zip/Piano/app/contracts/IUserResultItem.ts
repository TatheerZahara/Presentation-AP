export interface IUserResultItem {
    expectedKeyNumber: number;
    actualKeyNumber: number;
    correct: boolean;
}