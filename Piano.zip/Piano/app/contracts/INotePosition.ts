export interface INotePosition {
    key: string;
    yPos: number;
    keyNumber: number;
    imageName: string;
    type?: string;
}
