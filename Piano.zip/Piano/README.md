# Piano Note Trainer

Angular 2 based music notation sight reading game.

Why not [give the demo a try](http://ng2piano.azurewebsites.net/)?!

I've also written an [accompanying blog post about it](http://josephwoodward.co.uk/2016/01/angular-2-based-piano-note-training-game-side-project).

![Piano game](http://assets.josephwoodward.co.uk/blog/angular2_notetraininggame.png)

CSS Piano [source](http://cssdeck.com/labs/pure-css3-piano).
